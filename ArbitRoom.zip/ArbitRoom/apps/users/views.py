from django.shortcuts import render
from apps.setting.models import Setting
# Create your views here.
